# Replace different Python versions in the PATH with Python 3.12
$env:PATH = $env:PATH -replace 'Python313', 'Python312'
$env:PATH = $env:PATH -replace 'Python311', 'Python312'
$env:PATH = $env:PATH -replace 'Python310', 'Python312'
$env:PATH = $env:PATH -replace 'Python39', 'Python312'
$env:PATH = $env:PATH -replace 'Python38', 'Python312'
$env:PATH = $env:PATH -replace 'Python37', 'Python312'
$env:PATH = $env:PATH -replace 'Python36', 'Python312'

# Set the PYENVS environment variable to point to venvs of Python 3.12
$env:PYENVS = "$env:USERPROFILE\.pyenvs\Python312\"
