# Replace different Python versions in the PATH with Python 3.8
$env:PATH = $env:PATH -replace 'Python313', 'Python38'
$env:PATH = $env:PATH -replace 'Python312', 'Python38'
$env:PATH = $env:PATH -replace 'Python311', 'Python38'
$env:PATH = $env:PATH -replace 'Python310', 'Python38'
$env:PATH = $env:PATH -replace 'Python39', 'Python38'
$env:PATH = $env:PATH -replace 'Python37', 'Python38'
$env:PATH = $env:PATH -replace 'Python36', 'Python38'

# Set the PYENVS environment variable to point to venvs of Python 3.8
$env:PYENVS = "$env:USERPROFILE\.pyenvs\Python38\"
