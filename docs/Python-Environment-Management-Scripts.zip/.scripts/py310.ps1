# Replace different Python versions in the PATH with Python 3.10
$env:PATH = $env:PATH -replace 'Python313', 'Python310'
$env:PATH = $env:PATH -replace 'Python312', 'Python310'
$env:PATH = $env:PATH -replace 'Python311', 'Python310'
$env:PATH = $env:PATH -replace 'Python39', 'Python310'
$env:PATH = $env:PATH -replace 'Python38', 'Python310'
$env:PATH = $env:PATH -replace 'Python37', 'Python310'
$env:PATH = $env:PATH -replace 'Python36', 'Python310'

# Set the PYENVS environment variable to point to venvs of Python 3.10
$env:PYENVS = "$env:USERPROFILE\.pyenvs\Python310\"
