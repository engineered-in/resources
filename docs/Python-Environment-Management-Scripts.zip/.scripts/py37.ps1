# Replace different Python versions in the PATH with Python 3.7
$env:PATH = $env:PATH -replace 'Python313', 'Python37'
$env:PATH = $env:PATH -replace 'Python312', 'Python37'
$env:PATH = $env:PATH -replace 'Python311', 'Python37'
$env:PATH = $env:PATH -replace 'Python310', 'Python37'
$env:PATH = $env:PATH -replace 'Python39', 'Python37'
$env:PATH = $env:PATH -replace 'Python38', 'Python37'
$env:PATH = $env:PATH -replace 'Python36', 'Python37'

# Set the PYENVS environment variable to point to venvs of Python 3.7
$env:PYENVS = "$env:USERPROFILE\.pyenvs\Python37\"
