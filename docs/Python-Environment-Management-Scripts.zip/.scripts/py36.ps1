# Replace different Python versions in the PATH with Python 3.6
$env:PATH = $env:PATH -replace 'Python313', 'Python36'
$env:PATH = $env:PATH -replace 'Python312', 'Python36'
$env:PATH = $env:PATH -replace 'Python311', 'Python36'
$env:PATH = $env:PATH -replace 'Python310', 'Python36'
$env:PATH = $env:PATH -replace 'Python39', 'Python36'
$env:PATH = $env:PATH -replace 'Python38', 'Python36'
$env:PATH = $env:PATH -replace 'Python37', 'Python36'

# Set the PYENVS environment variable to point to venvs of Python 3.6
$env:PYENVS = "$env:USERPROFILE\.pyenvs\Python36\"
