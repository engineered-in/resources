# Replace different Python versions in the PATH with Python 3.9
$env:PATH = $env:PATH -replace 'Python313', 'Python39'
$env:PATH = $env:PATH -replace 'Python312', 'Python39'
$env:PATH = $env:PATH -replace 'Python311', 'Python39'
$env:PATH = $env:PATH -replace 'Python310', 'Python39'
$env:PATH = $env:PATH -replace 'Python38', 'Python39'
$env:PATH = $env:PATH -replace 'Python37', 'Python39'
$env:PATH = $env:PATH -replace 'Python36', 'Python39'

# Set the PYENVS environment variable to point to venvs of Python 3.9
$env:PYENVS = "$env:USERPROFILE\.pyenvs\Python39\"
