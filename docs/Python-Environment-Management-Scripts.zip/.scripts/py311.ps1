# Replace different Python versions in the PATH with Python 3.11
$env:PATH = $env:PATH -replace 'Python313', 'Python311'
$env:PATH = $env:PATH -replace 'Python312', 'Python311'
$env:PATH = $env:PATH -replace 'Python310', 'Python311'
$env:PATH = $env:PATH -replace 'Python39', 'Python311'
$env:PATH = $env:PATH -replace 'Python38', 'Python311'
$env:PATH = $env:PATH -replace 'Python37', 'Python311'
$env:PATH = $env:PATH -replace 'Python36', 'Python311'

# Set the PYENVS environment variable to point to venvs of Python 3.11
$env:PYENVS = "$env:USERPROFILE\.pyenvs\Python311\"
