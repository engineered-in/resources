# Check if a virtual environment with the given name exists
if (Test-Path "$env:pyenvs$($args[0])") {
    # Activate the virtual environment
    . "$env:pyenvs$($args[0])\Scripts\Activate.ps1"
} else {
    # Create a new virtual environment with the given name
    python -m venv "$env:pyenvs$($args[0])"
    Write-Output "run `pyenv $args[0]` to activate the newly created venv"
}
